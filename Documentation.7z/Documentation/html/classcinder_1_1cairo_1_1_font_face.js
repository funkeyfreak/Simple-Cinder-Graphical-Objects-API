var classcinder_1_1cairo_1_1_font_face =
[
    [ "FontFace", "classcinder_1_1cairo_1_1_font_face.html#a867ae935e979030749afa969ad123d58", null ],
    [ "FontFace", "classcinder_1_1cairo_1_1_font_face.html#a6ee7cffb7fe1f6a7fac1bbfd069e8c75", null ],
    [ "FontFace", "classcinder_1_1cairo_1_1_font_face.html#a3b97edaf6af8431c0b76af1c8cb8a806", null ],
    [ "~FontFace", "classcinder_1_1cairo_1_1_font_face.html#a456a654abfdf5e76b0f46d6a9dc8a8d3", null ],
    [ "getCairoFontFace", "classcinder_1_1cairo_1_1_font_face.html#ad2ef21625d62de0487248af314a2ade0", null ],
    [ "getType", "classcinder_1_1cairo_1_1_font_face.html#a563b39832666a94c145f37d93e759738", null ]
];