var structcairo__text__cluster__t =
[
    [ "num_bytes", "structcairo__text__cluster__t.html#a4936b5da097d8dc840d9fcd5d1c84b31", null ],
    [ "num_glyphs", "structcairo__text__cluster__t.html#ac3ba061cbce85dc9d81d1e3e3481b7d2", null ]
];