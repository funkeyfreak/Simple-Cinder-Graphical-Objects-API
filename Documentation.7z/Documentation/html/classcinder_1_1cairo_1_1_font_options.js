var classcinder_1_1cairo_1_1_font_options =
[
    [ "FontOptions", "classcinder_1_1cairo_1_1_font_options.html#a845970b19a92ed5f00587911ec759fdf", null ],
    [ "FontOptions", "classcinder_1_1cairo_1_1_font_options.html#a7010f8ac126b8215caaa4eb011456f35", null ],
    [ "~FontOptions", "classcinder_1_1cairo_1_1_font_options.html#a3f3707d1a5c3d565716413f36c9c410b", null ],
    [ "create", "classcinder_1_1cairo_1_1_font_options.html#a4a82a85caeabfb825f05b9bbfda6faf0", null ],
    [ "equal", "classcinder_1_1cairo_1_1_font_options.html#a0bfd86ae0660d5c0478af41bce0f7be4", null ],
    [ "getAntiAlias", "classcinder_1_1cairo_1_1_font_options.html#a678489c8461477d782d9dd367f5b29bc", null ],
    [ "getCairoFontOptions", "classcinder_1_1cairo_1_1_font_options.html#ae3d90d2d2a193b4540c5f67f2dfcc88b", null ],
    [ "getHintMetrics", "classcinder_1_1cairo_1_1_font_options.html#ac4fce1533bb9b7f9b75f50a50cd0057c", null ],
    [ "getHintStyle", "classcinder_1_1cairo_1_1_font_options.html#a7c8ce75e544610250b9995e24af2ec71", null ],
    [ "getSubPixelOrder", "classcinder_1_1cairo_1_1_font_options.html#a04a187eaaa64fee2226f40e5774feb7f", null ],
    [ "hash", "classcinder_1_1cairo_1_1_font_options.html#af3b04cebacbead45634c27443baece19", null ],
    [ "merge", "classcinder_1_1cairo_1_1_font_options.html#ae2db60bfd6720445860a4faedf315420", null ],
    [ "setAntiAlias", "classcinder_1_1cairo_1_1_font_options.html#a922e6fe7fb55bb7b3b8d9bc4c6d71ceb", null ],
    [ "setHintMetrics", "classcinder_1_1cairo_1_1_font_options.html#a5de01aa8e7574b5de45114b9cec6a437", null ],
    [ "setHintStyle", "classcinder_1_1cairo_1_1_font_options.html#a41756edb600811aed559102206281be1", null ],
    [ "setSubPixelOrder", "classcinder_1_1cairo_1_1_font_options.html#af56784729392783ae9ee377346476d08", null ],
    [ "status", "classcinder_1_1cairo_1_1_font_options.html#a5d7195afeb385b6d365bd84c7e7b3e5f", null ]
];