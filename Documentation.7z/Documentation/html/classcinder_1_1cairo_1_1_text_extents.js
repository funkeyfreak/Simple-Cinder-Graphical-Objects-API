var classcinder_1_1cairo_1_1_text_extents =
[
    [ "TextExtents", "classcinder_1_1cairo_1_1_text_extents.html#a8e8036d7df132b95553e8ccf22cdf554", null ],
    [ "TextExtents", "classcinder_1_1cairo_1_1_text_extents.html#a9a088210669a4541c6424ef4b804fb3a", null ],
    [ "~TextExtents", "classcinder_1_1cairo_1_1_text_extents.html#a469131c90702643a4760f70b0c9269e3", null ],
    [ "getCairoTextExtents", "classcinder_1_1cairo_1_1_text_extents.html#a34ecde6c6de0a261a5870d7a449bfab6", null ],
    [ "height", "classcinder_1_1cairo_1_1_text_extents.html#a0834033dcf6bb132228502a2549c5db9", null ],
    [ "height", "classcinder_1_1cairo_1_1_text_extents.html#ad0d4dab1ab9785a5d0b3732309298a6d", null ],
    [ "width", "classcinder_1_1cairo_1_1_text_extents.html#a1e706832c63c9c70fb5589708ac82ccb", null ],
    [ "width", "classcinder_1_1cairo_1_1_text_extents.html#a06b18961a25f344b7784686a3a6d41eb", null ],
    [ "xAdvance", "classcinder_1_1cairo_1_1_text_extents.html#a4d12eb4190ca81fc2e238ab75fe14e0e", null ],
    [ "xAdvance", "classcinder_1_1cairo_1_1_text_extents.html#a29ca78eda6db862cd85f34a021d1e2a8", null ],
    [ "xBearing", "classcinder_1_1cairo_1_1_text_extents.html#ab921fb17f4e2ab407bb2ad94f417921b", null ],
    [ "xBearing", "classcinder_1_1cairo_1_1_text_extents.html#a9832e1f020cc4c29be969ae6026d7cb4", null ],
    [ "yAdvance", "classcinder_1_1cairo_1_1_text_extents.html#add031e928cd1151e7036dd2b29593f7c", null ],
    [ "yAdvance", "classcinder_1_1cairo_1_1_text_extents.html#a13d57597bfc4b38607d8b35368412779", null ],
    [ "yBearing", "classcinder_1_1cairo_1_1_text_extents.html#ae46395c07a0c9f5d96bd2aa427094c5e", null ],
    [ "yBearing", "classcinder_1_1cairo_1_1_text_extents.html#a12222c1d1f7d74f54952505790425eeb", null ]
];