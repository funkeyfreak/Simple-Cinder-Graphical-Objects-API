var classcinder_1_1cairo_1_1_gradient =
[
    [ "Gradient", "classcinder_1_1cairo_1_1_gradient.html#a39578357b93ad09ee187a22bb7b76ed8", null ],
    [ "addColorStop", "classcinder_1_1cairo_1_1_gradient.html#ae1317fbe178f8e6353d6c60f1833aa0b", null ],
    [ "addColorStop", "classcinder_1_1cairo_1_1_gradient.html#a190f7e7befdd7fe29131f17086b7317c", null ],
    [ "addColorStopRgb", "classcinder_1_1cairo_1_1_gradient.html#aac46f257467f353056a7f5fdab5efbff", null ],
    [ "addColorStopRgba", "classcinder_1_1cairo_1_1_gradient.html#a7e137bda5c2800f1fdfc5330a460b502", null ],
    [ "getColorStopCount", "classcinder_1_1cairo_1_1_gradient.html#a77c75c7d82da9547f60454eed45b48a4", null ],
    [ "getColorStopRgba", "classcinder_1_1cairo_1_1_gradient.html#a4d684bdfe6274752c8291a3d9b626cac", null ]
];