var struct__cairo__rectangle__int =
[
    [ "height", "struct__cairo__rectangle__int.html#ae196a4b90408ab71b345b07d59c66e7e", null ],
    [ "width", "struct__cairo__rectangle__int.html#a12a8d585057d6ef11c1fc4c95d89195d", null ],
    [ "x", "struct__cairo__rectangle__int.html#ae092f612c6ad10dbc3d0d2bf1147f9c0", null ],
    [ "y", "struct__cairo__rectangle__int.html#acf545bac8856eb3221f7fdbb76e22fbc", null ]
];