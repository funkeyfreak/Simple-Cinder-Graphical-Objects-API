var struct__cairo__text__extents =
[
    [ "height", "struct__cairo__text__extents.html#a045205aff70af3e01074752327b62260", null ],
    [ "width", "struct__cairo__text__extents.html#a64f292901e48f38bf656f64f0646370c", null ],
    [ "x_advance", "struct__cairo__text__extents.html#a83fc00bf18b434abb732442b8f9a3022", null ],
    [ "x_bearing", "struct__cairo__text__extents.html#a6623eca4e7c7d69b834cfa3507b923ba", null ],
    [ "y_advance", "struct__cairo__text__extents.html#ad2abd893fbc45d09bd74d15cf94253cc", null ],
    [ "y_bearing", "struct__cairo__text__extents.html#a28b7086ad218793b2fdc627065b2a6be", null ]
];