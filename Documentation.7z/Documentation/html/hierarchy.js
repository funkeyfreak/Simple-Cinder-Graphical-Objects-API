var hierarchy =
[
    [ "_cairo_font_extents", "struct__cairo__font__extents.html", null ],
    [ "_cairo_matrix", "struct__cairo__matrix.html", null ],
    [ "_cairo_path_data_t", "union__cairo__path__data__t.html", null ],
    [ "_cairo_rectangle", "struct__cairo__rectangle.html", null ],
    [ "_cairo_rectangle_int", "struct__cairo__rectangle__int.html", null ],
    [ "_cairo_rectangle_list", "struct__cairo__rectangle__list.html", null ],
    [ "_cairo_text_extents", "struct__cairo__text__extents.html", null ],
    [ "_cairo_user_data_key", "struct__cairo__user__data__key.html", null ],
    [ "AppNative", null, [
      [ "CheckersApp", "class_checkers_app.html", null ]
    ] ],
    [ "Board", "class_board.html", null ],
    [ "cairo_glyph_t", "structcairo__glyph__t.html", null ],
    [ "cairo_path", "structcairo__path.html", null ],
    [ "cairo_text_cluster_t", "structcairo__text__cluster__t.html", null ],
    [ "Constraint", "class_constraint.html", null ],
    [ "cinder::cairo::Context", "classcinder_1_1cairo_1_1_context.html", null ],
    [ "cinder::cairo::FontExtents", "classcinder_1_1cairo_1_1_font_extents.html", null ],
    [ "cinder::cairo::FontFace", "classcinder_1_1cairo_1_1_font_face.html", null ],
    [ "cinder::cairo::FontOptions", "classcinder_1_1cairo_1_1_font_options.html", null ],
    [ "GraphicalObject", "class_graphical_object.html", [
      [ "CheckerPiece", "class_checker_piece.html", null ]
    ] ],
    [ "cinder::cairo::Matrix", "classcinder_1_1cairo_1_1_matrix.html", null ],
    [ "OccupencyGrid", "class_occupency_grid.html", null ],
    [ "cinder::cairo::Pattern", "classcinder_1_1cairo_1_1_pattern.html", [
      [ "cinder::cairo::Gradient", "classcinder_1_1cairo_1_1_gradient.html", [
        [ "cinder::cairo::GradientLinear", "classcinder_1_1cairo_1_1_gradient_linear.html", null ],
        [ "cinder::cairo::GradientRadial", "classcinder_1_1cairo_1_1_gradient_radial.html", null ]
      ] ],
      [ "cinder::cairo::PatternSolid", "classcinder_1_1cairo_1_1_pattern_solid.html", null ],
      [ "cinder::cairo::PatternSurface", "classcinder_1_1cairo_1_1_pattern_surface.html", null ]
    ] ],
    [ "Rect", "class_rect.html", null ],
    [ "Renderer", null, [
      [ "cinder::cairo::SvgRendererCairo", "classcinder_1_1cairo_1_1_svg_renderer_cairo.html", null ]
    ] ],
    [ "cinder::cairo::ScaledFont", "classcinder_1_1cairo_1_1_scaled_font.html", null ],
    [ "cinder::cairo::SurfaceBase", "classcinder_1_1cairo_1_1_surface_base.html", [
      [ "cinder::cairo::SurfaceEps", "classcinder_1_1cairo_1_1_surface_eps.html", null ],
      [ "cinder::cairo::SurfaceImage", "classcinder_1_1cairo_1_1_surface_image.html", null ],
      [ "cinder::cairo::SurfacePdf", "classcinder_1_1cairo_1_1_surface_pdf.html", null ],
      [ "cinder::cairo::SurfacePs", "classcinder_1_1cairo_1_1_surface_ps.html", null ],
      [ "cinder::cairo::SurfaceSvg", "classcinder_1_1cairo_1_1_surface_svg.html", null ]
    ] ],
    [ "SurfaceConstraints", null, [
      [ "cinder::SurfaceConstraintsCairo", "classcinder_1_1_surface_constraints_cairo.html", null ]
    ] ],
    [ "cinder::cairo::TextExtents", "classcinder_1_1cairo_1_1_text_extents.html", null ]
];