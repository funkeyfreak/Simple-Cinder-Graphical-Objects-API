var classcinder_1_1cairo_1_1_pattern_solid =
[
    [ "PatternSolid", "classcinder_1_1cairo_1_1_pattern_solid.html#a084dfceb8224a8a8cbd0b6cbd88fd07e", null ],
    [ "PatternSolid", "classcinder_1_1cairo_1_1_pattern_solid.html#a9f1e2ef9bcc528746f1ab65474fc5619", null ]
];