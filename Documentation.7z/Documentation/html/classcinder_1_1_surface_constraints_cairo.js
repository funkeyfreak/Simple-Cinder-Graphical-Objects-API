var classcinder_1_1_surface_constraints_cairo =
[
    [ "getChannelOrder", "classcinder_1_1_surface_constraints_cairo.html#abd85eeb30ff4bf3e4f4947ca6388326f", null ],
    [ "getRowBytes", "classcinder_1_1_surface_constraints_cairo.html#ab98eb8caa0f5300bff126583615fe31d", null ]
];