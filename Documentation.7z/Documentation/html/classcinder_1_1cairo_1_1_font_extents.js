var classcinder_1_1cairo_1_1_font_extents =
[
    [ "FontExtents", "classcinder_1_1cairo_1_1_font_extents.html#a13e099379c0cb5aee017344f343cfd45", null ],
    [ "FontExtents", "classcinder_1_1cairo_1_1_font_extents.html#ace8e1a65279934b5cdac4e9ebc6302b3", null ],
    [ "~FontExtents", "classcinder_1_1cairo_1_1_font_extents.html#a19ba96427aedec54b35298cd41443a06", null ],
    [ "ascent", "classcinder_1_1cairo_1_1_font_extents.html#a54fba12f5be411fe6e63741251683bbd", null ],
    [ "ascent", "classcinder_1_1cairo_1_1_font_extents.html#aef0c569fb8ac3a8a181cf5eca48d988f", null ],
    [ "descent", "classcinder_1_1cairo_1_1_font_extents.html#a57287497d2afe55d00874c6e5823a62a", null ],
    [ "descent", "classcinder_1_1cairo_1_1_font_extents.html#abfaf75ea78ab1dac99b3e696ba951556", null ],
    [ "getCairoFontExtents", "classcinder_1_1cairo_1_1_font_extents.html#a9b1a6f33e85b84c5e3838984d916890b", null ],
    [ "height", "classcinder_1_1cairo_1_1_font_extents.html#a42d89dd5f6fe6116e8184aed843a4a51", null ],
    [ "height", "classcinder_1_1cairo_1_1_font_extents.html#a6265be776c2ee314b03e7c072b5e5f47", null ],
    [ "maxXAdvance", "classcinder_1_1cairo_1_1_font_extents.html#ae8695c03f1f0e89213f84d7c60873e4a", null ],
    [ "maxXAdvance", "classcinder_1_1cairo_1_1_font_extents.html#a860fe91b4eca753acbb01b369a9fd5dc", null ],
    [ "maxYAdvance", "classcinder_1_1cairo_1_1_font_extents.html#ab8c7bb2cd17fe34b3585bc62c1c129d8", null ],
    [ "maxYAdvance", "classcinder_1_1cairo_1_1_font_extents.html#aaa5648e3ee639ad49788d9f20090c806", null ]
];