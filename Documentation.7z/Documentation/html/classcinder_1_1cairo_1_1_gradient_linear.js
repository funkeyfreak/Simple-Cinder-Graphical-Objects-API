var classcinder_1_1cairo_1_1_gradient_linear =
[
    [ "GradientLinear", "classcinder_1_1cairo_1_1_gradient_linear.html#ab604623fa2ea3ad81beb84ba74af2961", null ],
    [ "GradientLinear", "classcinder_1_1cairo_1_1_gradient_linear.html#a5728db2355cb0bd2cea4c78d2172df02", null ]
];