var structcairo__glyph__t =
[
    [ "index", "structcairo__glyph__t.html#a9388af296a2cfe82b6df8569355ec3f9", null ],
    [ "x", "structcairo__glyph__t.html#a5134676dae4951d92f4734dc7a85e552", null ],
    [ "y", "structcairo__glyph__t.html#ad88addb598014997d09b126ad443fb9a", null ]
];