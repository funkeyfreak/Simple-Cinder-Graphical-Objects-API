var struct__cairo__font__extents =
[
    [ "ascent", "struct__cairo__font__extents.html#addb0036eedb8e99ebdc90a1519a0c18f", null ],
    [ "descent", "struct__cairo__font__extents.html#afda21fe0df959af5c1313a47160e1adf", null ],
    [ "height", "struct__cairo__font__extents.html#ad20636c8462be4ce2b6c617768f71c5d", null ],
    [ "max_x_advance", "struct__cairo__font__extents.html#a0075c7468b2e8d0ebe68e294ee7c40fa", null ],
    [ "max_y_advance", "struct__cairo__font__extents.html#a6b191299fd994be2be1ae89c5fe03aa7", null ]
];