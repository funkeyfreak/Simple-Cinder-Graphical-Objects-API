var structcairo__path =
[
    [ "data", "structcairo__path.html#ac643fd9c0b62aa2af9af160c69684a39", null ],
    [ "num_data", "structcairo__path.html#a8bee3f292e7de91ee2e200dfa76f9a3c", null ],
    [ "status", "structcairo__path.html#a2b9662845eab409b8baf3a5ca10e7a24", null ]
];