var struct__cairo__rectangle__list =
[
    [ "num_rectangles", "struct__cairo__rectangle__list.html#a62d3775ec8d347e58c5c06648671ace0", null ],
    [ "rectangles", "struct__cairo__rectangle__list.html#a600c8042009a7e9e0799dc410a1b06a9", null ],
    [ "status", "struct__cairo__rectangle__list.html#a77da5fdd8e0af5ebb4b59bb101870fca", null ]
];