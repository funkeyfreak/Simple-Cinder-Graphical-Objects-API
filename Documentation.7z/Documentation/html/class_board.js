var class_board =
[
    [ "Board", "class_board.html#a9ee491d4fea680cf69b033374a9fdfcb", null ],
    [ "~Board", "class_board.html#af73f45730119a1fd8f6670f53f959e68", null ],
    [ "isOccupied", "class_board.html#a3662de51b33b2ad3e96f1f4694b361f5", null ],
    [ "updateBoard", "class_board.html#aa1e9675f86e4e5b9436ef15e57536d1e", null ]
];