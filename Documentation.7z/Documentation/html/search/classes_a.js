var searchData=
[
  ['textextents',['TextExtents',['../classcinder_1_1cairo_1_1_text_extents.html',1,'cinder::cairo']]]
];
