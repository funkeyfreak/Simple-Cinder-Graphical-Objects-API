var searchData=
[
  ['update',['update',['../class_checkers_app.html#a956bbf509770e654116e3da5e10d21af',1,'CheckersApp']]]
];
