var searchData=
[
  ['gradient',['Gradient',['../classcinder_1_1cairo_1_1_gradient.html',1,'cinder::cairo']]],
  ['gradientlinear',['GradientLinear',['../classcinder_1_1cairo_1_1_gradient_linear.html',1,'cinder::cairo']]],
  ['gradientradial',['GradientRadial',['../classcinder_1_1cairo_1_1_gradient_radial.html',1,'cinder::cairo']]],
  ['graphicalobject',['GraphicalObject',['../class_graphical_object.html',1,'']]]
];
