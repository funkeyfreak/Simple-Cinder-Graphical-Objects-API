var searchData=
[
  ['loadcenterpoints',['loadCenterPoints',['../class_checkers_app.html#a0e8845298df438901664b9b758a5f9cd',1,'CheckersApp']]],
  ['lookahead',['lookAhead',['../class_checkers_app.html#a443c5e2811180b82c42a923aaba2ffda',1,'CheckersApp']]]
];
