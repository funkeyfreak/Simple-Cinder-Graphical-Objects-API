var indexSectionsWithContent =
{
  0: "_abcdefgilmnoprstuvw~",
  1: "_bcfgmoprst",
  2: "acdefgilmnoprstuw~",
  3: "dsv",
  4: "f"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "typedefs"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Typedefs"
};

