var searchData=
[
  ['transformdistance',['transformDistance',['../classcinder_1_1cairo_1_1_matrix.html#a21a1287618c1535aa97489f11b322fb2',1,'cinder::cairo::Matrix']]],
  ['transformpoint',['transformPoint',['../classcinder_1_1cairo_1_1_matrix.html#a365e2cc74c93a74e76ee851b3a33b997',1,'cinder::cairo::Matrix']]]
];
